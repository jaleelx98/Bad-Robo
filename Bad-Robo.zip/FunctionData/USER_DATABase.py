#Target Can Edit...
INSHACKE_TARGETS = [
    'johncena',
    'neymarjr',
    'pappya_gaikwad_official',
    'team_kalimayam',
    'selenagomez',
    'freefirebr_oficial',
    'cristiano',
    'insta_squadron',
    'sunnyleone',
    'therock'
    ]


RE_HASH_TARGETS = [
'#like4like #likeforlike #likeforlikes #instalike #likeforfollow #like4likes #likes #tagsforlikes #likes #likeforlikeback #liketime',
'#mallu #gainwithmtaaraw #gaintrick #gainwithspikes #gainwithmchina #gainwiththeepluto #gainwithxtiandela #republicadominicana #nyc #memes #memesdaily',
'#sections #gainwithbundi #chuvadelikes #chuvadeseguidores #memesaccount #memestagram #takipet #sections #hashtronaut #hunteroflove',
'#keralagram #followers #keralagodsowncountry #shahxn #mumbai #followers#followers  #keralagodsowncountry #shahxn #mumbai #followers',
'#teamkalimayam #positivevibes #instagood #igers #gainwithmchina #godsowncountry #bhfyp #gaintrick #art #insta #delhi #keralatourism',
'#keralagallery #kochi #malayalam #chennai  #photooftheday #mumbai #mallu',
'#kerala360 #india #photography #instagra #nature #travel',
    ]


COMMENT_S = [
    "NICE❤",
    "LIKE❣❣❣",
    "WOW💥",
    "FOLLOW BACK💌",
    "HEY FOLLOW ME",
    "COOL💟",
    "HELLO",
    "BEST",
    ]