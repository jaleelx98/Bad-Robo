import base64, codecs
magic = 'I0ltcG9ydGluZyBNb2R1bGVzCmltcG9ydCBvcwppbXBvcnQgdGltZQoKI0NsZWFyIHRoZSBDb25zb2xlIEZ1bmMuLi4KZGVmIGNsZWFyKCk6CiAgICBpZiBvcy5uYW1lID09ICJudCI6CiAgICAgICAgb3Muc3lzdG'
love = 'IgXPWwoUZvXDbtVPNtMJkmMGbXVPNtVPNtVPOipl5mrKA0MJ0bVzAfMJSlVvxXPvZtMTIznJ5yVUEbMFOwo3IhqTEiq24tMaIhLl4XMTIzVTAiqJ50MT93ovuwo3IhqTIlK3EcoJHcBtbtVPNtq2ucoTHtL291oaEy'
god = 'cl90aW1lOgogICAgICAgIG1pbnMsIHNlY3MgPSBkaXZtb2QoY291bnRlcl90aW1lLCA2MCkKICAgICAgICB0aW1lciA9ICd7OjAyZH06ezowMmR9Jy5mb3JtYXQobWlucywgc2VjcykKICAgICAgICBwcmludCgiIC'
destiny = 'OpqGNjZJWoZmR7ZJ1GoTIypTyhMl4hYyk1ZQNkLyfjoIk1ZQNkLyfmZGfkoFVfqTygMKVfVTIhMQ0vKUWpqGNjZJWoZT0vXDbtVPNtVPNtVUEcoJHhp2kyMKNbZFxXVPNtVPNtVPOwo3IhqTIlK3EcoJHtYG0tZD=='
joy = '\x72\x6f\x74\x31\x33'
trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))