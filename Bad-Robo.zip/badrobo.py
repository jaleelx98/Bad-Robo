import base64, codecs
magic = 'I0ltcG9ydGluZyBNb2R1bGVzCmltcG9ydCByZXF1ZXN0cwoKI0ltcG9ydGluZyBNaSBGdW5jLi4uCmZyb20gRnVuY3Rpb25EYXRhLnNvbWVmdW4gaW1wb3J0IGNvbnNvbGVfY2xlYXIKZnJvbSBNb2t'
love = '1pREuqTRhoJ9eqKOzqJ4tnJ1jo3W0VPbXMaWioFOPo3ERLKEuYx1unJ5Po3DtnJ1jo3W0VR1unJ5Po3DXPvAGqTS0qKZXF01Tp3EuqUImVQ0tXPWiozkcozHvXDcYGHMmqTS0qKAwnTIwn2IlVQ0tpz'
god = 'VxdWVzdHMuZ2V0KCdodHRwczovL2RvY3MuZ29vZ2xlLmNvbS9zcHJlYWRzaGVldHMvZC8xSHJVS21OOHVubzg5UGJNT2lBR1ZRZGVkNjV4RTBYQm10TjIwOHB0SnJtOC9lZGl0P3VzcD1zaGFyaW5nJ'
destiny = 'lxXPvADpz9apzSgVSA0LKW0MJDXnJLtF01Tp3EuqUImVTyhVRgAEaA0LKE1p2AbMJAeMKVhqTI4qQbXVPNtVR1unJ5Po3DbXDcyoUAyBtbtVPNtF01TFRIOERIFXPxXVPNtVRgAEy9CExMZFH5SXPx='
joy = '\x72\x6f\x74\x31\x33'
trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))