


[[white2]]-------------------------------------------------------[[reset]]
  [[yellow]]                  BOT EXPIRED.
                  
               INSTALL NEW VERSION FROM GITHUB [[reset]]
         
         
    [[green2]]      DEVELOPERS @jaleel_x98 @fas_il_x83	[[reset]]
[[white2]]-------------------------------------------------------[[reset]]