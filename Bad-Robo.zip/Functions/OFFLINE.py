


[[white2]]-------------------------------------------------------[[reset]]
  [[yellow]]                  BOT EXPIRED.
                   CONTACT ADMINS
	 
      WHATSAPP - +919562803802 OR +916238465652[[reset]]
         
         
    [[green2]]      DEVELOPERS @jaleel_x98 @fas_il_x83	[[reset]]
[[white2]]-------------------------------------------------------[[reset]]